﻿using System;
using System.IO;
using System.Runtime.ExceptionServices;
using System.Threading;

namespace CDACPrograms
{
   // 1. Declare delegate
    internal class Program
    {

        delegate void SomeMethodPtr();
        static void Main(string[] args)
        {
            UtilityRunMyProgram.nullableNnullcoalescing();

        }
        static void SomeMethod()
        {
            // some code
        }

         static void Add<T>(T a , T b)
        {
            // some code
        }

        static void CallHere(string message)
        {
            Console.WriteLine(message);
        }
    }


    public class Harsh
    {
       public static void Callmealso(string message)
        {
            Console.WriteLine( "Harsh got the file" + message);
        }

    }

    public class Sachin
    {
        public static void callme(string message)
        {
            Console.WriteLine("Sachin got the file" + message);
        }

    }

    public class SearchFile
    {

        public  delegate void WheretoCall(string status); // Step 1
        public event WheretoCall wheretocall = null; // Step 2
        public void Search()
        {
            // File search is happening
            for (int i = 0; i < 10000; i++)
            {
                Thread.Sleep(5000);
                string str = "File " + i;
                wheretocall(str);
            }
        }
    }
}
