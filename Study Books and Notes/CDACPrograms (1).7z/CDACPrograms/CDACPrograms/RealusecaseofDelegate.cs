﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CDACPrograms
{

    public delegate bool isElibileForAsection(Student EmployeeToPromotion);
    public class Student
    {
        public int RollNo { get; set; }
        public string Name { get; set; }
        public string Gender { get; set; }
        public int Standard { get; set; }
        public int Points{ get; set; }
        public int TotalMarks { get; set; }


        public static void PromoteStudent(List<Student> stuents, isElibileForAsection isElibilibleforAsection)
        {
            foreach (Student stu in stuents)
            {
                if (isElibilibleforAsection(stu))
                {
                    Console.WriteLine($"Student  {stu.Name}  is moved to A-Section");
                }
            }
        }

    }





}
