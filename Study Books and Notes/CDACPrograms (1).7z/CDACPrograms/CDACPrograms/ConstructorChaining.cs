﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CDACPrograms
{
    class User
    {
        public User()
        {
            Console.Write("Hi, ");
        }
        public User(string a) : this()
        {
            Console.Write(a);
        }
        public User(string a, string b) : this("welcome")
        {
            Console.Write(a + " " + b);
        }
    }
}
