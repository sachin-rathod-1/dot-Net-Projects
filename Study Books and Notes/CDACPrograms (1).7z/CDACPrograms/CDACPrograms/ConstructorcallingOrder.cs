﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CDACPrograms
{
    public class Animal1
    {
        static Animal1()
        {
            Console.WriteLine("I am animal constructor.");
        }
    }
    public class Dog1 : Animal1
    {
        static Dog1()
        {
            Console.WriteLine("I am dog constructor.");
        }
    }
}
