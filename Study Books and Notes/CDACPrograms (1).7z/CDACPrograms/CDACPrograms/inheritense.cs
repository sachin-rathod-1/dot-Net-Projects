﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CDACPrograms
{
    public class Animal
    {

        public void display()
        {

            Console.WriteLine("Hello world");
        }
        public virtual void speak()
        {
            Console.WriteLine("Eating...");
        }
    }
    public class Dog : Animal
    {
        public void display( string str)
        {
            Console.WriteLine(str);
        }
        public override void speak()
        {
            Console.WriteLine("Dog is speaking...");
        }
    }

    public class Cat : Animal
    {
        public override void speak()
        {
            Console.WriteLine("Cat is speaking...");
        }
    }

    public class Elephant : Animal
    {
        public override void speak()
        {
            Console.WriteLine("Elephant is speaking..");
        }
    }
}
