﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CDACPrograms
{
    internal class Collection
    {

        public static  void StackUse()

        {
            Stack my_stack = new Stack();

            // Adding elements in the Stack
            // Using Push method
            my_stack.Push("Geeks");
            my_stack.Push("geeksforgeeks");
            my_stack.Push('G');
            my_stack.Push(null);
            my_stack.Push(1234);
            my_stack.Push(490.98);

        
            var v =my_stack.Pop();

            // Accessing the elements
            // of my_stack Stack
            // Using foreach loop
            foreach (var elem in my_stack)
            {
                Console.WriteLine(elem);
            }
        }
    }
}
