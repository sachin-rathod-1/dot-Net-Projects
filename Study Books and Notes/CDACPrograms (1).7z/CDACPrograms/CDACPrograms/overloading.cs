﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CDACPrograms
{
    internal class overloading
    {
        void display(int a)
        {
            Console.WriteLine("Arguments: " + a);
        }

        // method with two parameters
        void display(int a, int b)
        {
            Console.WriteLine("Arguments: " + a + " and " + b);
        }

        void display(char b, int a)
        {
            Console.WriteLine("Arguments: " + a + " and " + b);
        }
    }
    internal class Test
    {
        int a;
        int b;
       public Test(int a) : this(10,20)
        {
            this.a = a;
            Console.WriteLine("first");

        }

        Test(int a ,int b)
        {
            this.a = a;
            this.b = b;
            Console.WriteLine(a);
            Console.WriteLine(b);
        }

        public void display()
        {
            Console.WriteLine(a);
            Console.WriteLine(b);
        }
    }
}




