﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CDACPrograms
{
    internal class UseOFArrayList
    {
        public void DisplayArrayList()
        {
            ArrayList list = new ArrayList();
            list.Add(10);
            list.Add(20);
            list.Add(30);
            list.Add(40);
            list.Add(50); list.Add(60);
            list.Add(70);
           

            foreach (var item in list)
            {
                Console.WriteLine(item.ToString());
            }
        }

    }
}
