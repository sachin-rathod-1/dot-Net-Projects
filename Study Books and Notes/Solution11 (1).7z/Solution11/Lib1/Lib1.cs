﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lib1
{
    public class LibClass1
    {
        public void M1()
        {
        }
        public void M2()
        { }
        public void M3()
        { }
        public void M4()
        { }
        public void M5()
        { }
    }

    public class LibClass2    {
        protected internal void M1()
        { 
        }
        public void M2()
        { }
        public void M3()
        { }
        public void M4()
        { }
        public void M5()
        { }
    }




    class A : LibClass2
    {
        public void Test()
        {
            LibClass2 libClass2 = new LibClass2();
           // libClass2.M1();
        }
    }


   
}
