﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lib1;

namespace Lib2
{
    public class Lib2class2 : Lib1.LibClass2
    {
        public void M1()
        {
         
           M1();

        }
        public void M2()
        { }
        public void M3()
        { }
        public void M4()
        { }
        public void M5()
        { }
    }

    public class Lib2Class2
    {
        public void M1()
        { 
           LibClass1 class1 = new LibClass1();
            class1.M1();
        
        }
        public void M2()
        { }
        public void M3()
        { }
        public void M4()
        { }
        public void M5()
        { }

       public class A : LibClass2
        {
            public void Test()
            {
                M1();
            }

        }

        
    }

    public static class AA
    {
        public static void NewMethod(this Lib1.LibClass1 ob)
        {
            Console.WriteLine("Hello I m extended method of Lib1 Class 1");
        }
    }

}
