﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lib1
{
    internal class TEST
    {
        public void M1()
        {
            LibClass2 obj = new LibClass2();
            obj.M1();
        }
    }
}
