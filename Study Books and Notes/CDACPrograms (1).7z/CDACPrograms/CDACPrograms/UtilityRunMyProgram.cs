﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CDACPrograms
{
    public static class UtilityRunMyProgram
    {
        public static void IndexerProg()
        {
            CDACEmployee emp = new CDACEmployee(101, "Pranaya", "SSE", 10000, "Mumbai", "IT", "Male");
            Console.WriteLine("EID = " + emp["ID"]);
            Console.WriteLine("Name = " + emp["Name"]);
            Console.WriteLine("Job = " + emp["job"]);
            Console.WriteLine("Salary = " + emp["salary"]);
            Console.WriteLine("Location = " + emp["Location"]);
            Console.WriteLine("Department = " + emp["department"]);
            Console.WriteLine("Gender = " + emp["Gender"]);
            emp["Name"] = "Kumar";
            emp["salary"] = 65000;
            emp["Location"] = "BBSR";
            Console.WriteLine("=======Afrer Modification=========");
            Console.WriteLine("EID = " + emp["ID"]);
            Console.WriteLine("Name = " + emp["Name"]);
            Console.WriteLine("Job = " + emp["job"]);
            Console.WriteLine("Salary = " + emp["salary"]);
            Console.WriteLine("Location = " + emp["Location"]);
            Console.WriteLine("Department = " + emp["department"]);
            Console.WriteLine("Gender = " + emp["Gender"]);

        }


        public static void GenericProg()
        {
            //Generics program logic

        }

        public static void nullableNnullcoalescing()
        {

            int? i = 10;
            i = null;

            string str1 = null;
            string str2 = null;
            string str3 = null;
            string str4 = null;
            string str5 = null;

            string str6 = " abc ";


            string resultstr = str1 ?? str2 ?? str3 ?? str4 ?? str5 ?? str6;

            Console.WriteLine(resultstr);
        }
    }
}

