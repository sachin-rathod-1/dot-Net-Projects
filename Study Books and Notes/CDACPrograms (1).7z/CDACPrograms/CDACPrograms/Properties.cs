﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CDACPrograms
{
    class Person
    {
        private string name; // field

        private int age; // field

        public string Name   // property
        {
            get { return name; }   // get method
            set { name = value; }  // set method
        }

        public int Age   // property
        {
            get { return age; }   // get method
            set {
                if (value > 0)
                    age = value;
                else
                    Console.WriteLine("Invalid age ");
            }
            // set method
        }
    }
}
