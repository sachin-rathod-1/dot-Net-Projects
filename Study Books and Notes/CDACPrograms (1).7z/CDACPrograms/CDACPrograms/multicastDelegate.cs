﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CDACPrograms
{
     delegate void MDelegate();// declaration 
    class DM
    {
        static public void Display()
        {
            Console.WriteLine("Meerut");
        }
        static public void print()
        {
            Console.WriteLine("Roorkee");
        }
        static public void printmycity()
        {
            Console.WriteLine("Jaipur");
        }
    }


    class Xyz
    {
         public void Display()
        {
            Console.WriteLine("Heloooo");
        }
         public void print()
        {
            Console.WriteLine("oooooo");
        }
         public void printmycity()
        {
            Console.WriteLine("pppppppp");
        }
    }
}
