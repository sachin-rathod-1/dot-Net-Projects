﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CDACPrograms
{
    internal class UseOfHashtable
    {
        public void DisplayHashtable()
        {
            Hashtable  t=new Hashtable();
            t.Add()
            t.Add("k1", "Sachin");
            t.Add("k2", "Vipul");
            t.Add("k3", "Pooja1");
            t.Add("k4", "Pooja2");

            //hashtable does not maitain order 

            //Arraylist maintain order

            foreach (var key in t.Keys)
            {
                Console.WriteLine(t[key]); 
            }
        }
    }
}
